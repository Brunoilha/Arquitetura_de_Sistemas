const db = require("../data/db");

function getAllOrders(req,res){
    return res.json(db.orders);
}

function createOrder(req,res){
    const {client, items} = req.body;

    if (!Array.isArray(items) || items.length === 0){
        return res.status(400).json({erro: "O campo 'itens' é obrigatório e deve ser um array com pelo menos 1 item.",});
    }

    const normalItems = [];

    for (const [index, item] of items.entries()){
        const productId = Number(item?.productId);
        const amount = Number(item?.amount);

        if (!Number.isInteger(productId) || productId <= 0){
            return res.status(400).json({erro:`Item ${index + 1}: 'productId' inválido.`,});
        }

        if (!Number.isInteger(amount) || amount <= 0){
            return res.status(400).json({erro:`Item ${index + 1}: 'quantidade' inválida.`,});
        }

        normalItems.push({
        productId,
        name: products.name,
        unitPrice: products.price,
        amount,
        subtotal: Number((product.price * amount).toFixed(2)),
        _refProduct: product,
        });
    }

    const total = Number(normalItems.reduce((acc,it) => acc + it.subtotal, 0).toFixed(2));

    const newOrder = {
        id: db.nextOrderId++,
        client: typeof client === "string" ? client.trim() : null,
        items: normalItems.map(({_refProduct, ...public}) => public),
        total, createdOn: new Date().toString(),
    };

    for (const it of normalItems){
        it._refProduct.stock -= it.amount;
    }

    db.orders.push(newOrder);

    return res.status(201).json(newOrder);
}

module.exports = {
  getAllOrders,
  createOrder,
};